import os
import json
from datetime import datetime, date
import joblib
from django.shortcuts import render

# --- Load models ONCE when the server starts (not per-request) ---
MODELS_DIR = os.path.join(os.path.dirname(__file__), 'models_data')

ets_temp_model = joblib.load(os.path.join(MODELS_DIR, 'ets_temp_model.pkl'))
ets_humidity_model = joblib.load(os.path.join(MODELS_DIR, 'ets_humidity_model.pkl'))

with open(os.path.join(MODELS_DIR, 'last_known_date.json')) as f:
    LAST_KNOWN_DATE = datetime.strptime(json.load(f)['last_date'], '%Y-%m-%d').date()


def predict_weather(request):
    context = {}

    if request.method == 'POST':
        date_str = request.POST.get('target_date', '').strip()

        # --- Input validation ---
        if not date_str:
            context['error'] = "Please enter a date."
        else:
            try:
                target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            except ValueError:
                context['error'] = "That doesn't look like a valid date. Please use the date picker."
                target_date = None

            if target_date:
                days_ahead = (target_date - LAST_KNOWN_DATE).days

                if days_ahead <= 0:
                    context['error'] = f"Please choose a date after {LAST_KNOWN_DATE} (the model's training data ends there)."
                elif days_ahead > 3650:  # ~10 years - sanity cap, ETS accuracy degrades far into the future anyway
                    context['error'] = "Please choose a date within the next 10 years for a meaningful forecast."
                else:
                    temp_pred = ets_temp_model.forecast(steps=days_ahead).iloc[-1]
                    humidity_pred = ets_humidity_model.forecast(steps=days_ahead).iloc[-1]

                    context['result'] = {
                        'date': target_date,
                        'temp': round(temp_pred, 1),
                        'humidity': round(humidity_pred, 1),
                    }

        context['submitted_date'] = date_str

    return render(request, 'forecast/form.html', context)